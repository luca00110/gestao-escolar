import _sqlite3

DATABASE = "escola.db"

def conectar_banco():
    conexao = _sqlite3.connect("escola.db")
    conexao.row_factory = _sqlite3.Row

    return conexao

def criar_tabelas():
    conexao = conectar_banco()

    conexao.execute("""
        CREATE TABLE IF NOT EXISTS alunos ( 
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        nome TEXT NOT NULL,
        email TEXT NOT NULL,
        idade INTEGER NOT NULL 
        )
    """)